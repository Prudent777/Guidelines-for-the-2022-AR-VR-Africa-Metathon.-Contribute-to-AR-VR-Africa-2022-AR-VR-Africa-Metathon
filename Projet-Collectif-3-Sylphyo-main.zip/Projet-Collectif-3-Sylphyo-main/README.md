# Projet-Collectif-3-Sylphyo
Projet de M2 pour le développement sur Unity d'une application d'apprentissage du Sylphyo

Le Sylphyo est un instrument numérique développé par Aodyo.
C'est un synthétiseur, doublé d'un controlleur MIDI à vent.


Le but est ici de développer un "compagnon numérique" afin d'aider à l'apprentissage de l'utilisation des différents gestes de modulation/canaux MIDI
